public interface TrainerRegulation {
    public final int minAge = 10;
    public final int maxParty = 6;
    String toString();
}
